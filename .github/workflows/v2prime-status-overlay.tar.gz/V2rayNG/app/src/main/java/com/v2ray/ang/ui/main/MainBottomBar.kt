package com.v2ray.ang.ui.main

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R

/**
 * A quiet bottom bar when disconnected. Only the BAR turns green when connected:
 * the power button deliberately keeps one dark-blue color in every state.
 */
@Composable
fun MainBottomBar(
    displayText: String,
    isRunning: Boolean,
    isConnected: Boolean,
    isDarkTheme: Boolean,
    isRepairing: Boolean,
    onAction: (MainAction) -> Unit,
) {
    val backgroundColor = MaterialTheme.colorScheme.background
    val barBrush = if (isConnected) {
        Brush.horizontalGradient(listOf(Color(0xFF128650), Color(0xFF0F6242)))
    } else {
        Brush.horizontalGradient(listOf(backgroundColor, backgroundColor))
    }
    // No state-dependent recoloring: power stays slate/blue, ON and OFF.
    val powerBrush = Brush.linearGradient(listOf(Color(0xFF8294AC), Color(0xFF3C526F)))

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(barBrush)
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(106.dp)
                .clickable(enabled = isConnected) { onAction(MainAction.TestCurrentServer) },
        ) {
            // Show scan progress only while the VPN is OFF. Once service starts,
            // the banner becomes silent, while the bar can still turn green.
            if (!isRunning && displayText.isNotBlank()) {
                Text(
                    text = displayText,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        // Physical LEFT space is reserved for the power button even in RTL.
                        .absolutePadding(left = 120.dp, right = 20.dp)
                        .align(AbsoluteAlignment.CenterRight)
                        .semantics { contentDescription = displayText },
                    textAlign = TextAlign.Right,
                    lineHeight = 19.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            modifier = Modifier
                // Keep the whole circular button INSIDE the bottom bar and screen.
                .align(AbsoluteAlignment.CenterLeft)
                .absoluteOffset(x = 13.dp)
                .size(86.dp)
                .shadow(10.dp, CircleShape)
                .clip(CircleShape)
                .background(powerBrush)
                .border(3.dp, Color.White.copy(alpha = 0.82f), CircleShape)
                .clickable(
                    enabled = !isRepairing,
                    role = Role.Button,
                    onClick = { onAction(MainAction.ToggleService) }
                ),
            contentAlignment = androidx.compose.ui.Alignment.Center,
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_power_beauty_24dp),
                contentDescription = stringResource(if (isRunning) R.string.acc_stop else R.string.acc_start),
                tint = Color.White,
                modifier = Modifier.size(45.dp),
            )
        }
    }
}
