package com.v2ray.ang.ui.main

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.v2ray.ang.R

/** Minimal client toolbar: advanced overflow/search/navigation icons deliberately hidden. */
@Composable
fun MainTopBar(
    isLoading: Boolean,
    subscriptionTitle: String,
    isUpdatingSubscription: Boolean,
    easyConnectStage: EasyConnectStage,
    showSearch: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onSearchClose: () -> Unit,
    onSearchToggle: (Boolean) -> Unit,
    onMenuClick: () -> Unit,
    onAction: (MainAction) -> Unit,
    onMoreMenuAction: (MainMoreMenuAction) -> Unit,
) {
    Column(modifier = Modifier.statusBarsPadding()) {
        // Large high-contrast one-tap control replaces the subscription title.
        // The initial app-launch refresh still shows the real progress banner.
        val stageLabel = when (easyConnectStage) {
            EasyConnectStage.IDLE -> "اتصال خودکار به بهترین سرور"
            EasyConnectStage.STOPPING -> "در حال قطع اتصال قبلی…"
            EasyConnectStage.REFRESHING -> "در حال بروزرسانی اشتراک…"
            EasyConnectStage.TESTING -> "در حال انتخاب بهترین سرور…"
            EasyConnectStage.CONNECTING -> "در حال اتصال، لطفاً صبر کنید…"
            EasyConnectStage.FAILED -> "تلاش مجدد برای اتصال آسان"
        }
        val busy = easyConnectStage != EasyConnectStage.IDLE &&
            easyConnectStage != EasyConnectStage.FAILED
        Surface(
            onClick = { onAction(MainAction.EasyConnect) },
            enabled = !busy && !isUpdatingSubscription && !isLoading,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 7.dp)
                .heightIn(min = 76.dp),
            shape = RoundedCornerShape(17.dp),
            color = if (isUpdatingSubscription && !busy) Color(0xFFDEF5E7) else Color(0xFF16834E),
            contentColor = Color.White,
            border = BorderStroke(1.dp, Color(0xFF84C8A0)),
            shadowElevation = 4.dp,
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = if (isUpdatingSubscription && !busy)
                        "در حال بروزرسانی اشتراک، لطفاً صبر کنید…" else stageLabel,
                    textAlign = TextAlign.Center,
                    color = if (isUpdatingSubscription && !busy) Color(0xFF185F3D) else Color.White,
                    fontSize = 19.sp,
                    lineHeight = 26.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Bold,
                )
                if (!busy && !isUpdatingSubscription) {
                    Text(
                        text = "برای اتصال فقط یک‌بار لمس کنید",
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp,
                        color = Color.White,
                    )
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CompactMainActionButton(
                title = stringResource(R.string.auto_clipboard_short),
                drawable = R.drawable.ic_copy,
                enabled = !isLoading,
                modifier = Modifier.weight(1f),
                onClick = { onAction(MainAction.ImportClipboard) },
            )
            CompactMainActionButton(
                title = "افزودن QR",
                drawable = R.drawable.ic_scan_24dp,
                enabled = !isLoading,
                modifier = Modifier.weight(1f),
                onClick = { onAction(MainAction.ImportQRcode) },
            )
            CompactMainActionButton(
                title = stringResource(R.string.auto_update_short),
                drawable = R.drawable.ic_refresh_24dp,
                enabled = !isLoading,
                modifier = Modifier.weight(1f),
                onClick = { onAction(MainAction.UpdateSubscriptions) },
            )
            CompactMainActionButton(
                title = stringResource(R.string.auto_real_delay_short),
                drawable = R.drawable.ic_check_update_24dp,
                enabled = !isLoading,
                modifier = Modifier.weight(1f),
                onClick = { onAction(MainAction.TestRealAllServers) },
            )
            CompactMainActionButton(
                title = stringResource(R.string.auto_sort_short),
                drawable = R.drawable.ic_outline_filter_alt_24,
                enabled = !isLoading,
                modifier = Modifier.weight(1f),
                onClick = { onAction(MainAction.SortByTestResults) },
            )
        }
    }
}

@Composable
private fun CompactMainActionButton(
    title: String,
    drawable: Int,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.aspectRatio(1f),
        shape = RoundedCornerShape(13.dp),
        color = colors.surface,
        contentColor = colors.onSurface,
        border = BorderStroke(1.dp, colors.primary.copy(alpha = 0.28f)),
        tonalElevation = 1.dp,
        shadowElevation = 3.dp,
    ) {
        Column(
            modifier = Modifier.padding(2.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier.size(27.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(colors.primary.copy(alpha = 0.11f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(drawable),
                    contentDescription = null,
                    tint = colors.primary,
                    modifier = Modifier.size(18.dp),
                )
            }
            Spacer(modifier = Modifier.size(2.dp))
            Text(
                text = title,
                fontSize = 8.sp,
                lineHeight = 10.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
